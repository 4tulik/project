<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>                        


<div class="row">
    <div class="col_12">
        <style>
            /* CSS used for demo */
            ul#icons { margin-top: 5px; padding: 0px; font-size: 1.24em;}
            ul#icons li {margin-right: 3px; margin-bottom: 5px; position: relative; padding: 0px 0; cursor: pointer; float: left; list-style: none; }
            ul#icons span.ui-icon { float: left; margin: 0 4px; }
        </style>
        <div class="col_6">
            <div class="widget_inside">
                <ul id="icons" class="ui-widget ui-helper-clearfix">Ocenie przedszkola
                    <li class="ui-state-default ui-corner-all" title=".ui-icon-carat-1-n"><span class="ui-icon ui-icon-carat-1-n"></span></li>
                    <li class="ui-state-default ui-corner-all" title=".ui-icon-carat-1-s"><span class="ui-icon ui-icon-carat-1-s"></span></li>
                </ul>
            </div></div>
        
            <div class="col_6 last">
                <div class="widget_inside">
                <ul id="icons" class="ui-widget ui-helper-clearfix">Ilości opinii
                    <li class="ui-state-default ui-corner-all" title=".ui-icon-carat-1-n"><span class="ui-icon ui-icon-carat-1-n"></span></li>
                    <li class="ui-state-default ui-corner-all" title=".ui-icon-carat-1-s"><span class="ui-icon ui-icon-carat-1-s"></span></li>
                </ul>
            </div></div>
    </div>

</div>