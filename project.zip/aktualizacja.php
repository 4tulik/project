<?php 
system("zip -r archiwum.zip ./");
?>