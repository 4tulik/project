<?php
echo "Witaj". $_SESSION['imie'];

?>
